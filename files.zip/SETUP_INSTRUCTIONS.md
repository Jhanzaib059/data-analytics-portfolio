# 🚀 How to Set Up This GitHub Repository

Follow these steps to publish your portfolio on GitHub.

---

## Step 1: Create the Main Repository

1. Go to [github.com](https://github.com) and sign in (or create a free account)
2. Click **"New repository"** (green button, top right)
3. Name it: `data-analytics-portfolio`
4. Set it to **Public**
5. Do NOT initialize with a README (you already have one)
6. Click **"Create repository"**

---

## Step 2: Upload the Files

### Option A — Upload via GitHub website (easiest)
1. Open your new repository on GitHub
2. Click **"Add file" → "Upload files"**
3. Drag and drop the entire folder contents
4. Click **"Commit changes"**

### Option B — Use Git (command line)
```bash
cd muhammad-jhanzaib-portfolio
git init
git add .
git commit -m "Initial portfolio commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/data-analytics-portfolio.git
git push -u origin main
```

---

## Step 3: Set Up Your GitHub Profile README (Optional but Recommended)

This creates a special banner that appears on your GitHub profile page.

1. Create a **new repository** named exactly as your GitHub username (e.g., `muhammad-jhanzaib`)
2. Make it **Public** and check **"Add a README file"**
3. Copy the content from `.github/PROFILE_README.md` into that README
4. Save — your profile page will now show your intro card!

---

## Step 4: Pin the Repository

1. Go to your GitHub profile page
2. Click **"Customize your pins"**
3. Pin `data-analytics-portfolio`

---

## Step 5: Update Your LinkedIn

Add your GitHub portfolio URL to your LinkedIn profile:
`https://github.com/YOUR_USERNAME/data-analytics-portfolio`

---

✅ Done! Your professional data analytics portfolio is now live on GitHub.
