# Data Validation Checklist — Multi-System Environments

Use this checklist when performing end-to-end data validation across Application Portals, Billing Servers, CRM platforms, or any multi-system integration.

---

## Phase 1: Pre-Validation Setup

- [ ] Identify all data sources involved (source systems, target systems, APIs)
- [ ] Document expected data flows and transformation rules
- [ ] Confirm access to all environments (dev, staging, production)
- [ ] Baseline snapshot of record counts and key field values
- [ ] Agree on validation scope with stakeholders

---

## Phase 2: Structural Validation

- [ ] Schema matches expected definition (field names, data types, nullable flags)
- [ ] No extra or missing columns vs. specification
- [ ] Primary keys are unique and non-null
- [ ] Foreign key relationships are intact
- [ ] Date/time fields are in the correct format and timezone

---

## Phase 3: Content & Integrity Validation

- [ ] Record counts match between source and target
- [ ] No duplicate records
- [ ] Null/blank values within acceptable thresholds
- [ ] Numeric fields within expected ranges (no negative where positive expected)
- [ ] String fields free of unexpected special characters or encoding issues
- [ ] Calculated fields match expected formulas

---

## Phase 4: Business Rule Validation

- [ ] All mandatory business fields populated
- [ ] Conditional logic applied correctly (e.g., status = 'Active' only if contract date is future)
- [ ] Referential data maps correctly to lookup tables (e.g., region codes, account types)
- [ ] Financial totals reconcile with source systems
- [ ] Client-specific rules documented and verified

---

## Phase 5: API & Integration Validation

- [ ] API responses match expected payload structure
- [ ] HTTP status codes appropriate (200, 201, 400, 500)
- [ ] Latency within SLA thresholds
- [ ] Error handling tested for edge cases (empty responses, timeouts)
- [ ] Data persisted correctly after API call

---

## Phase 6: Regression & Smoke Testing

- [ ] All previously passing tests still pass after changes
- [ ] Critical data flows tested end-to-end in staging before production
- [ ] Defects logged in JIRA with severity, steps to reproduce, and expected vs. actual results

---

## Phase 7: Sign-Off

- [ ] QA metrics report generated and shared with DevOps / product team
- [ ] All Critical and High severity defects resolved or risk-accepted
- [ ] Stakeholder sign-off received
- [ ] Validation results archived for audit trail

---

## Defect Severity Reference

| Severity | Definition | Example |
|---|---|---|
| Critical | Data loss / incorrect financial data | Billing amounts wrong by >1% |
| High | Major feature broken, no workaround | API returning null for required field |
| Medium | Feature degraded, workaround exists | Date format inconsistency |
| Low | Minor issue, cosmetic | Extra whitespace in string field |
