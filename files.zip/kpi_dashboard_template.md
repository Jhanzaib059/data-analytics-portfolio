# KPI Dashboard Template — B2B Account Management

## Dashboard Overview

**Purpose:** Track sales performance, client retention, and pipeline health across B2B accounts.  
**Update Frequency:** Weekly (operational) / Monthly (executive reporting)  
**Audience:** Senior Leadership, Account Management Team

---

## Section 1: Revenue & Growth

| Metric | Current Period | Previous Period | Change (%) | Target |
|---|---|---|---|---|
| Total Revenue | $XXX,XXX | $XXX,XXX | +X% | $XXX,XXX |
| Revenue per Account | $X,XXX | $X,XXX | +X% | $X,XXX |
| New ARR | $XX,XXX | $XX,XXX | +X% | $XX,XXX |
| Expansion Revenue | $X,XXX | $X,XXX | +X% | $X,XXX |

---

## Section 2: Retention & Churn

| Metric | Value | Benchmark | Status |
|---|---|---|---|
| Customer Retention Rate | XX% | >90% | 🟢 / 🟡 / 🔴 |
| Churn Rate (Monthly) | X% | <5% | 🟢 / 🟡 / 🔴 |
| At-Risk Accounts | XX | <10 | 🟢 / 🟡 / 🔴 |
| Average Contract Duration | XX months | 12 months | 🟢 / 🟡 / 🔴 |

---

## Section 3: Pipeline & Conversion

| Stage | Count | Value | Conv. Rate |
|---|---|---|---|
| Leads | XXX | $XXX,XXX | — |
| Qualified Opportunities | XX | $XX,XXX | XX% |
| Proposals Sent | XX | $XX,XXX | XX% |
| Closed Won | XX | $XX,XXX | XX% |

**Overall Pipeline Conversion Rate:** XX%

---

## Section 4: Client Satisfaction

| Segment | CSAT Score | NPS | Trend |
|---|---|---|---|
| Enterprise (>$50K ARR) | X.X/10 | +XX | ↑ / → / ↓ |
| Mid-Market ($10K–$50K) | X.X/10 | +XX | ↑ / → / ↓ |
| SMB (<$10K) | X.X/10 | +XX | ↑ / → / ↓ |

---

## Section 5: Account Segmentation

### High-Value Accounts (Top 20%)
> These accounts represent 80% of revenue — prioritize proactive outreach.

- Account count: XX
- Combined ARR: $XXX,XXX
- Avg. CSAT: X.X
- Risk flagged: X accounts

### Growth Targets (Mid-Tier)
> Accounts with expansion potential based on usage analytics.

- Account count: XX
- Upsell pipeline value: $XX,XXX

---

## Notes & Action Items

- [ ] Follow up on at-risk accounts flagged this month
- [ ] Schedule QBR for top 10 accounts by ARR
- [ ] Update segmentation model with latest usage data
- [ ] Prepare monthly performance report for leadership
