# ⚙️ CI/CD Data Validation Pipelines

This folder documents CI/CD pipeline configurations and strategies used to automate data quality checks and reduce post-release defect rates.

## Contents

| File | Description |
|---|---|
| `jenkins_pipeline_overview.md` | Jenkins pipeline strategy for data validation |
| `regression_smoke_test_strategy.md` | Regression and smoke testing cycle documentation |

## Tech Stack

| Tool | Role |
|---|---|
| **Jenkins** | Pipeline orchestration and scheduling |
| **TestNG** | Test framework for automated data validation |
| **SOAPUI** | API performance testing and payload validation |
| **LoadComplete** | Load testing and bottleneck identification |
| **JIRA** | Defect tracking and sprint reporting |

## Pipeline Stages

```
[Code Commit]
     ↓
[Trigger Jenkins Build]
     ↓
[Smoke Tests — Critical Path Only]
     ↓
[Data Validation — Schema + Content Checks]
     ↓
[Regression Suite — Full Data Integrity]
     ↓
[Performance Tests — Load & API Response]
     ↓
[QA Metrics Report Generated]
     ↓
[Deploy to Production ✅ / Rollback 🔴]
```

## Key Outcomes

- Reduced post-release data defect rates by streamlining regression and smoke testing cycles
- Generated automated QA metrics reports distributed to DevOps and product teams
- Ensured data integrity across Application Portals and Charging & Billing Servers

---
> Based on experience at IFBOTIX PVT LTD, Karachi (Jan 2021 – Jul 2022).
